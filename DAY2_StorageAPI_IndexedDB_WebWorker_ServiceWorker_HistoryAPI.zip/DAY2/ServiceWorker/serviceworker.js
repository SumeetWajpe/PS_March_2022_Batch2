var cacheName = "v3";
var cacheAssets = [
  "Index.html",
  "About.html",
  "js/script.js",
  "css/styles.css",
];
// install
self.addEventListener("install", function (e) {
  console.log("Service Worker : Installed !");
  // configure the cache !
  e.waitUntil(
    caches
      .open(cacheName)
      .then(function (cache) {
        cache.addAll(cacheAssets);
      })
      .then(() => self.skipWaiting())
  );
});
// activate
self.addEventListener("activate", function (e) {
  console.log("Service Worker : Activated !");
  e.waitUntil(
    caches.keys().then(function (cacheNames) {
      return Promise.all(
        cacheNames.map(function (c) {
          if (c !== cacheName) {
            return caches.delete(c);
          }
        })
      );
    })
  );
});

//fetch
self.addEventListener("fetch", function (e) {
  e.respondWith(
    fetch(e.request).catch(function () {
      return caches.match(e.request); // fetch resources from the cache in case of n/w failure !
    })
  );
});
