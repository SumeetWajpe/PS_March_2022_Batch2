if (navigator.serviceWorker) {
  window.addEventListener("load", function () {
    this.navigator.serviceWorker.register("serviceworker.js").then(
      function () {
        console.log("Service Worker : Registered !");
      },
      function (err) {
        console.log("Service Worker : Registration failed !", err);
      }
    );
  });
}
