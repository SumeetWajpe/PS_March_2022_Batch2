// 1. No access to window , document
// 2. No access to local,session storage, global variables from main thread
// 3. Access to IndexedDB, XMLHttpRequest , fetch
onmessage = function (msg) {
  var largeArray = [];
  for (let i = 0; i < 7000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 5000; j++) {
      largeArray[i][j] = Math.random();
    }
  }
  postMessage(largeArray[5000][3000]);
};
