const express = require("express");
const path = require("path");
const app = express();
const port = 3000;

var courses = require("./models/courses.model");

app.use(express.json());
app.use(express.static(path.join(__dirname, "static")));

app.get("/", (req, res) => {
  //   res.send("Hello World!");
  res.sendFile("Courses.html", { root: __dirname });
});

app.get("/courses", (req, res) => {
  res.json(courses);
});

app.post("/newcourse", (req, res) => {
  let newcourse = req.body;
  courses = [...courses, newcourse]; // || push()
  res.json({ msg: "success" });
});

app.delete("/courses/:id", (req, res) => {
  let theCourseId = +req.params.id;
  console.log("Deleting course from server : ", theCourseId);

  // db interaction
  courses = courses.filter((course) => course.id != theCourseId); // Immutability
  console.log(courses);
  res.json({ msg: "success" });
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
