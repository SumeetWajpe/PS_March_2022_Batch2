function GetPosts() {
  return new Promise(function (resolve, reject) {
    var xmlhttpReq = new XMLHttpRequest();
    xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
    xmlhttpReq.onreadystatechange = function () {
      if (xmlhttpReq.readyState == 4 && xmlhttpReq.status == 200) {
        resolve(xmlhttpReq.responseText);
      } else if (xmlhttpReq.readyState == 4 && xmlhttpReq.status !== 200) {
        reject("Something went wrong !");
      }
    };
    xmlhttpReq.send(); // places the async call !
  });
}
