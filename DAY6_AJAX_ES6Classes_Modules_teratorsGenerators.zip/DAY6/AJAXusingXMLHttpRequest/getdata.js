function GetPosts(callback) {
  var xmlhttpReq = new XMLHttpRequest();
  xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlhttpReq.onreadystatechange = function () {
    if (xmlhttpReq.readyState == 4 && xmlhttpReq.status == 200) {
      callback(null, xmlhttpReq.responseText);
    } else if (xmlhttpReq.readyState == 4 && xmlhttpReq.status !== 200) {
      callback("Something went wrong !", null);
    }
  };
  xmlhttpReq.send(); // places the async call !
}
