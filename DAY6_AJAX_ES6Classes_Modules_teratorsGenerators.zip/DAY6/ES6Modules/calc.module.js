import * as MathModule from "./math.module.js";

console.log(`The product is ${MathModule.Product(20, 30)}`);

// import Addition, { Product as Multiplication } from "./math.module.js";

// console.log(`The addition is : ${Addition(20, 30)}`);
// console.log(`The product is : ${Multiplication(20, 30)}`);
