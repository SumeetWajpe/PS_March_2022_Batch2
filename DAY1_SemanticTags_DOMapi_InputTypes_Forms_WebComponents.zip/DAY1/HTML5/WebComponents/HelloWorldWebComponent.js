class HelloWebComponent extends HTMLElement {
  constructor() {
    super();
    console.log("Hello Web Component !");
  }

  connectedCallback() {
    var msg = document.createElement("div");
    msg.innerHTML = "Hello";
    this.appendChild(msg);
  }
}

customElements.define("hello-world", HelloWebComponent);
