import { Add } from "./module.js";

console.log(`The addition is : ${Add(20, 30)}`);
